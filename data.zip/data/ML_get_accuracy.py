with open("y_test.csv", "r") as file:
    con1 = file.read()
con1 = con1.split()
epoch = int(input("Enter Epoch: "))

for i in range(1, epoch + 1):
    with open("y_pred_" + str(i) + ".csv", "r") as file:
        con2 = file.read()
    con2 = con2.split()
    match = 0
    for lab1, lab2 in zip(con1, con2):
        if lab1 == lab2:
            match += 1
    print("Epoch " + str(i) + ": " + str(match / len(con1)))

input()
